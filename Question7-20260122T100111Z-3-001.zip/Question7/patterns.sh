tr -c 'a-zA-Z' '\n' < "$1" | tr 'A-Z' 'a-z' | grep -E '^[aeiou]+$' > vowels.txt
tr -c 'a-zA-Z' '\n' < "$1" | tr 'A-Z' 'a-z' | grep -E '^[^aeiou]+$' > consonants.txt
tr -c 'a-zA-Z' '\n' < "$1" | tr 'A-Z' 'a-z' | grep -E '^[^aeiou][a-z]*$' | grep -E '[aeiou]' > mixed.txt