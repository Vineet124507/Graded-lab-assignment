mkdir -p "$1/backup"

for file in "$1"/*
do
  mv "$file" "$1/backup/" &
  echo "Moved $file with PID $!"
done

wait
echo "All background jobs completed"
