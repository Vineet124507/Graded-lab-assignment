if [ $# -ne 1 ]; then
  echo "Error: Please provide exactly one argument."
  exit 1
fi

if [ -f "$1" ]; then
  wc "$1"
elif [ -d "$1" ]; then
  total=$(find "$1" -type f | wc -l)
  txt=$(find "$1" -type f -name "*.txt" | wc -l)
  echo "Total files: $total"
  echo "Text files: $txt"
else
  echo "Error: Path does not exist."
fi