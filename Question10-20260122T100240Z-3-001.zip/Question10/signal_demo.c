#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void handle_term(int sig)
{
  printf("Received SIGTERM\n");
}

void handle_int(int sig)
{
  printf("Received SIGINT. Exiting gracefully.\n");
  exit(0);
}

int main()
{
  signal(SIGTERM, handle_term);
  signal(SIGINT, handle_int);

  if (fork() == 0)
  {
    sleep(5);
    kill(getppid(), SIGTERM);
    return 0;
  }

  if (fork() == 0)
  {
    sleep(10);
    kill(getppid(), SIGINT);
    return 0;
  }

  while (1)
    pause();
}
