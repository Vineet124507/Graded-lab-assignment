echo "Only in dirA:"
comm -23 <(ls dirA | sort) <(ls dirB | sort)

echo "Only in dirB:"
comm -13 <(ls dirA | sort) <(ls dirB | sort)

echo "Files with different content:"
for file in $(comm -12 <(ls dirA | sort) <(ls dirB | sort))
do
  cmp -s "dirA/$file" "dirB/$file" || echo "$file differs"
done